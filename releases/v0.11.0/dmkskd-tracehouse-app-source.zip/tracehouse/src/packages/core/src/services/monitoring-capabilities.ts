/**
 * MonitoringCapabilitiesService
 * 
 * Probes a ClickHouse server to detect which observability features are
 * available. Designed to run once per connection and cache the result
 * in a global store so all pages can conditionally render features.
 */

import type { IClickHouseAdapter } from '../adapters/types.js';
import type {
  MonitoringCapabilities,
  MonitoringCapability,
} from '../types/monitoring-capabilities.js';
import {
  PROBE_SYSTEM_LOG_TABLES,
  PROBE_MONITORING_SETTINGS,
  PROBE_ZOOKEEPER,
  PROBE_SERVER_VERSION,
  PROBE_CLOUD_SERVICE,
  PROBE_CPU_PROFILER_SAMPLES,
  PROBE_TRACEHOUSE_SAMPLING_TABLES,
  PROBE_SYSTEM_TABLE_ACCESS_TABLES,
} from '../queries/monitoring-capabilities-queries.js';
import { tagQuery } from '../queries/builder.js';
import { TAB_INTERNAL, sourceTag } from '../queries/source-tags.js';
import { parseTTL } from '../utils/ttl-parser.js';

export class MonitoringCapabilitiesServiceError extends Error {
  constructor(message: string, public readonly cause?: Error) {
    super(message);
    this.name = 'MonitoringCapabilitiesServiceError';
  }
}

/** Metadata for each system log table we probe */
const LOG_TABLE_META: Record<string, { label: string; description: string; category: MonitoringCapability['category']; source: string }> = {
  text_log: {
    label: 'Text Log',
    description: 'Server text log messages (errors, warnings, info). Enables log-level filtering in UI.',
    category: 'logging',
    source: 'system.text_log',
  },
  query_log: {
    label: 'Query Log',
    description: 'Completed query history with timing, memory, and profile events.',
    category: 'profiling',
    source: 'system.query_log',
  },
  query_thread_log: {
    label: 'Query Thread Log',
    description: 'Per-thread breakdown of query execution. Enables thread-level CPU attribution.',
    category: 'profiling',
    source: 'system.query_thread_log',
  },
  query_views_log: {
    label: 'Query Views Log',
    description: 'Materialized view execution during queries.',
    category: 'profiling',
    source: 'system.query_views_log',
  },
  part_log: {
    label: 'Part Log',
    description: 'Merge, mutation, and part lifecycle events. Enables merge history and CPU attribution.',
    category: 'introspection',
    source: 'system.part_log',
  },
  trace_log: {
    label: 'Trace Log',
    description: 'Stack trace sampling for CPU and memory profiling. Enables flamegraphs.',
    category: 'tracing',
    source: 'system.trace_log',
  },
  opentelemetry_span_log: {
    label: 'OpenTelemetry Spans',
    description: 'Distributed tracing spans. Enables trace correlation with external systems.',
    category: 'tracing',
    source: 'system.opentelemetry_span_log',
  },
  metric_log: {
    label: 'Metric Log',
    description: '1-second snapshots of system.metrics (gauges) and system.events (ProfileEvents deltas). Enables metric time-series charts.',
    category: 'metrics',
    source: 'system.metric_log',
  },
  asynchronous_metric_log: {
    label: 'Async Metric Log',
    description: '~60-second snapshots of OS-level metrics from /proc, cgroups, and jemalloc (system.asynchronous_metrics).',
    category: 'metrics',
    source: 'system.asynchronous_metric_log',
  },
  crash_log: {
    label: 'Crash Log',
    description: 'Server crash/fatal error records.',
    category: 'logging',
    source: 'system.crash_log',
  },
  processors_profile_log: {
    label: 'Processors Profile Log',
    description: 'Per-processor pipeline profiling. Enables detailed query pipeline analysis.',
    category: 'profiling',
    source: 'system.processors_profile_log',
  },
  backup_log: {
    label: 'Backup Log',
    description: 'Backup and restore operation history.',
    category: 'logging',
    source: 'system.backup_log',
  },
  s3queue_log: {
    label: 'S3Queue Log',
    description: 'S3Queue table engine processing log.',
    category: 'logging',
    source: 'system.s3queue_log',
  },
  blob_storage_log: {
    label: 'Blob Storage Log',
    description: 'Blob storage (S3/GCS/Azure) operation log.',
    category: 'logging',
    source: 'system.blob_storage_log',
  },
  session_log: {
    label: 'Session Log',
    description: 'Login/logout and session lifecycle events.',
    category: 'logging',
    source: 'system.session_log',
  },
  zookeeper_log: {
    label: 'ZooKeeper Log',
    description: 'ZooKeeper/Keeper request log for replication debugging.',
    category: 'introspection',
    source: 'system.zookeeper_log',
  },
  transactions_info_log: {
    label: 'Transactions Log',
    description: 'Transaction lifecycle events.',
    category: 'introspection',
    source: 'system.transactions_info_log',
  },
  filesystem_cache_log: {
    label: 'Filesystem Cache Log',
    description: 'Filesystem cache operations for remote storage.',
    category: 'introspection',
    source: 'system.filesystem_cache_log',
  },
  filesystem_read_prefetches_log: {
    label: 'FS Read Prefetch Log',
    description: 'Filesystem read prefetch operations.',
    category: 'introspection',
    source: 'system.filesystem_read_prefetches_log',
  },
  asynchronous_insert_log: {
    label: 'Async Insert Log',
    description: 'Asynchronous insert operation log.',
    category: 'logging',
    source: 'system.asynchronous_insert_log',
  },
};

export class MonitoringCapabilitiesService {
  constructor(private adapter: IClickHouseAdapter) {}

  /**
   * Probe all monitoring capabilities. Safe to call — catches errors
   * per-probe so partial results are still returned.
   */
  async probe(): Promise<MonitoringCapabilities> {
    const [version, logTables, settings, hasZk, hasIntrospection, isCloud, cpuProfilerSampleCount, tracehouseTables, systemTableAccess] = await Promise.all([
      this.probeVersion(),
      this.probeLogTables(),
      this.probeSettings(),
      this.probeZookeeper(),
      this.probeIntrospectionFunctions(),
      this.probeCloudService(),
      this.probeCPUProfilerSamples(),
      this.probeTracehouseSamplingTables(),
      this.probeSystemTableAccess(),
    ]);

    const capabilities: MonitoringCapability[] = [];

    // Add log table capabilities
    for (const [tableId, meta] of Object.entries(LOG_TABLE_META)) {
      const tableInfo = logTables.get(tableId);
      const available = !!tableInfo;
      const detail = tableInfo
        ? `${tableInfo.engine} · ${formatRowCount(tableInfo.totalRows)} rows`
        : 'Table not found';

      capabilities.push({
        id: tableId,
        label: meta.label,
        description: meta.description,
        available,
        category: meta.category,
        detail,
        ttl: tableInfo?.ttl ?? null,
        source: meta.source,
      });
    }

    // Add profile events capability (derived from settings)
    // This requires both query_log AND the log_profile_events setting enabled.
    // Without the setting, query_log exists but ProfileEvents columns are empty.
    const logProfileEvents = settings.get('log_profile_events');
    const profileEventsEnabled = logProfileEvents?.value === '1';
    const hasQueryLogTable = logTables.has('query_log');
    capabilities.push({
      id: 'query_log_profile_events',
      label: 'Query Profile Events',
      description: 'Per-query ProfileEvents counters (CPU time, IO, cache hits). Enables resource attribution.',
      available: hasQueryLogTable && profileEventsEnabled,
      category: 'profiling',
      detail: !hasQueryLogTable
        ? 'query_log not available'
        : profileEventsEnabled
          ? 'Enabled (log_profile_events=1)'
          : 'Disabled — set log_profile_events=1 to collect per-query counters',
      source: 'setting: log_profile_events',
    });

    // Add OpenTelemetry tracing probability
    const otelProb = settings.get('opentelemetry_start_trace_probability');
    const otelAvailable = logTables.has('opentelemetry_span_log');
    if (otelProb) {
      const prob = parseFloat(otelProb.value);
      const otelCap = capabilities.find(c => c.id === 'opentelemetry_span_log');
      if (otelCap) {
        otelCap.detail = `${otelCap.detail} · trace probability: ${prob}`;
        if (prob === 0 && otelAvailable) {
          otelCap.detail += ' (table exists but tracing disabled)';
        }
      }
    }

    // Enrich trace_log capability with CPU profiler status
    const cpuProfilerPeriod = settings.get('query_profiler_cpu_time_period_ns');
    const realProfilerPeriod = settings.get('query_profiler_real_time_period_ns');
    const traceLogCap = capabilities.find(c => c.id === 'trace_log');
    if (traceLogCap && traceLogCap.available) {
      const cpuNs = cpuProfilerPeriod ? parseInt(cpuProfilerPeriod.value, 10) : 0;
      const realNs = realProfilerPeriod ? parseInt(realProfilerPeriod.value, 10) : 0;
      const parts: string[] = [];
      if (cpuNs > 0) parts.push(`CPU: ${(cpuNs / 1_000_000).toFixed(0)}ms`);
      else parts.push('CPU profiler: off');
      if (realNs > 0) parts.push(`Real: ${(realNs / 1_000_000).toFixed(0)}ms`);
      else parts.push('Real profiler: off');
      traceLogCap.detail = `${traceLogCap.detail} · ${parts.join(', ')}`;
    }

    // Add CPU profiler active capability — detects whether the profiler is
    // actually producing samples. Settings can say "on" but samples will be
    // empty when the container lacks the SYS_PTRACE Linux capability (common
    // in Kubernetes without explicit securityContext configuration).
    const hasTraceLog = logTables.has('trace_log');
    const cpuNs = cpuProfilerPeriod ? parseInt(cpuProfilerPeriod.value, 10) : 0;
    const profilerSettingOn = cpuNs > 0;
    const hasCpuSamples = cpuProfilerSampleCount > 0;
    const cpuProfilerActive = hasTraceLog && profilerSettingOn && hasCpuSamples;
    let cpuProfilerDetail: string;
    if (!hasTraceLog) {
      cpuProfilerDetail = 'trace_log not available';
    } else if (!profilerSettingOn) {
      cpuProfilerDetail = 'CPU profiler disabled — set query_profiler_cpu_time_period_ns > 0';
    } else if (!hasCpuSamples) {
      cpuProfilerDetail = 'Profiler enabled but no samples collected — container may be missing SYS_PTRACE capability (required on Kubernetes)';
    } else {
      cpuProfilerDetail = `Active — ${cpuProfilerSampleCount} samples in last 5 min`;
    }
    capabilities.push({
      id: 'cpu_profiler_active',
      label: 'CPU Profiler',
      description: 'Verifies that the CPU query profiler is actually capturing stack trace samples (not just configured).',
      available: cpuProfilerActive,
      category: 'profiling',
      detail: cpuProfilerDetail,
      source: 'setting: query_profiler_cpu_time_period_ns',
    });

    // Add ZooKeeper capability
    capabilities.push({
      id: 'zookeeper',
      label: 'ZooKeeper / Keeper',
      description: 'Coordination service for replication. Enables replica health monitoring.',
      available: hasZk,
      category: 'introspection',
      detail: hasZk ? 'Connected' : 'Not configured or not accessible',
      source: 'config.xml: zookeeper',
    });

    // Add introspection functions capability (needed for flamegraphs and CPU sampling)
    // We probe this by actually calling demangle('') — the setting value in
    // system.settings can be stale or reflect the wrong profile, so a functional
    // test is more reliable.
    const introspectionSetting = settings.get('allow_introspection_functions');
    const introspectionEnabled = hasIntrospection;
    const settingValue = introspectionSetting?.value;
    capabilities.push({
      id: 'introspection_functions',
      label: 'Introspection Functions',
      description: 'Functions like demangle() and addressToSymbol() for stack trace symbolization. Required for flamegraphs and CPU sampling.',
      available: introspectionEnabled,
      category: 'profiling',
      detail: introspectionEnabled
        ? `Enabled${settingValue === '1' ? '' : ' (functional test passed)'}`
        : `Disabled (set allow_introspection_functions=1)`,
      source: 'setting: allow_introspection_functions',
    });

    // ClickStack (HyperDX) embedded log viewer — available in CH 26.2+
    const [major, minor] = this.parseVersion(version);
    const hasClickStack = major > 26 || (major === 26 && minor >= 2);
    capabilities.push({
      id: 'clickstack',
      label: 'ClickStack',
      description: 'Embedded HyperDX log viewer UI at /clickstack/. Enables deep-link from trace logs.',
      available: hasClickStack,
      category: 'logging',
      detail: hasClickStack
        ? `Available (v${version})`
        : `Requires ClickHouse 26.2+ (current: v${version})`,
      source: 'server version ≥ 26.2',
    });

    // ClickHouse Cloud detection — affects feature availability
    // (e.g. no cpu_id in trace_log, no direct OS metrics)
    capabilities.push({
      id: 'cloud_service',
      label: 'ClickHouse Cloud',
      description: 'Managed ClickHouse Cloud service. Some OS-level metrics (cpu_id, OS counters) are not available.',
      available: isCloud,
      category: 'introspection',
      detail: isCloud ? 'ClickHouse Cloud detected' : 'Self-hosted',
      source: 'system.clusters',
    });

    // Tracehouse processes_history — live process sampling (setup_sampling.sh)
    const hasProcessesHistory = tracehouseTables.has('processes_history');
    const processesInfo = tracehouseTables.get('processes_history');
    capabilities.push({
      id: 'tracehouse_processes_history',
      label: 'Process Sampling',
      description: 'Live process sampling via refreshable MV (tracehouse.processes_history). Enables query resource timelines.',
      available: hasProcessesHistory,
      category: 'profiling',
      detail: hasProcessesHistory
        ? `${processesInfo!.engine} · ${formatRowCount(processesInfo!.totalRows)} rows`
        : 'Not installed — run infra/scripts/setup_sampling.sh',
      source: 'tracehouse.processes_history',
    });

    // Tracehouse merges_history — live merge sampling (setup_sampling.sh)
    const hasMergesHistory = tracehouseTables.has('merges_history');
    const mergesInfo = tracehouseTables.get('merges_history');
    capabilities.push({
      id: 'tracehouse_merges_history',
      label: 'Merge Sampling',
      description: 'Live merge sampling via refreshable MV (tracehouse.merges_history). Enables merge X-Ray timelines.',
      available: hasMergesHistory,
      category: 'profiling',
      detail: hasMergesHistory
        ? `${mergesInfo!.engine} · ${formatRowCount(mergesInfo!.totalRows)} rows`
        : 'Not installed — run infra/scripts/setup_sampling.sh',
      source: 'tracehouse.merges_history',
    });

    // System table access capabilities — these tables always exist on ClickHouse
    // but may not be accessible due to privilege restrictions.
    const SYSTEM_TABLE_META: Record<string, { label: string; description: string; category: MonitoringCapability['category'] }> = {
      merges: {
        label: 'Active Merges',
        description: 'Currently running merges. Enables the Merge Tracker active merges view.',
        category: 'introspection',
      },
      mutations: {
        label: 'Active Mutations',
        description: 'Currently running mutations. Enables the Merge Tracker mutations view.',
        category: 'introspection',
      },
      clusters: {
        label: 'Cluster Topology',
        description: 'Cluster configuration and node list. Enables the Cluster page.',
        category: 'introspection',
      },
      replicas: {
        label: 'Replication Status',
        description: 'Per-table replication health and queue status. Enables the Replication page.',
        category: 'introspection',
      },
      parts: {
        label: 'Table Parts',
        description: 'Active data parts per table. Enables part-level detail in Database Explorer and Analytics.',
        category: 'introspection',
      },
      databases: {
        label: 'Database List',
        description: 'Database metadata. Enables the Database Explorer top-level view.',
        category: 'introspection',
      },
      processes: {
        label: 'Running Processes',
        description: 'Currently executing queries. Enables real-time running query monitoring.',
        category: 'introspection',
      },
    };

    for (const tableName of PROBE_SYSTEM_TABLE_ACCESS_TABLES) {
      const accessible = systemTableAccess.has(tableName);
      const meta = SYSTEM_TABLE_META[tableName];
      if (!meta) continue;
      capabilities.push({
        id: `system_${tableName}`,
        label: meta.label,
        description: meta.description,
        available: accessible,
        category: meta.category,
        detail: accessible
          ? 'Accessible'
          : 'Insufficient privileges to SELECT from system.' + tableName,
        source: `system.${tableName}`,
      });
    }

    return {
      probedAt: new Date(),
      serverVersion: version,
      capabilities,
    };
  }

  private async probeVersion(): Promise<string> {
    try {
      const rows = await this.adapter.executeQuery<{ version: string }>(tagQuery(PROBE_SERVER_VERSION, sourceTag(TAB_INTERNAL, 'serverVersion')));
      return rows[0]?.version ?? 'unknown';
    } catch {
      return 'unknown';
    }
  }

  private async probeLogTables(): Promise<Map<string, { engine: string; totalRows: number; totalBytes: number; ttl: string | null }>> {
    const result = new Map<string, { engine: string; totalRows: number; totalBytes: number; ttl: string | null }>();
    try {
      const rows = await this.adapter.executeQuery<{
        name: string;
        engine: string;
        total_rows: number;
        total_bytes: number;
        create_table_query: string;
      }>(tagQuery(PROBE_SYSTEM_LOG_TABLES, sourceTag(TAB_INTERNAL, 'logTables')));

      for (const row of rows) {
        result.set(String(row.name), {
          engine: String(row.engine),
          totalRows: Number(row.total_rows) || 0,
          totalBytes: Number(row.total_bytes) || 0,
          ttl: parseTTL(String(row.create_table_query || '')),
        });
      }
    } catch (error) {
      console.error('[MonitoringCapabilitiesService] probeLogTables error:', error);
    }
    return result;
  }

  private async probeSettings(): Promise<Map<string, { value: string; changed: boolean; description: string }>> {
    const result = new Map<string, { value: string; changed: boolean; description: string }>();
    try {
      const rows = await this.adapter.executeQuery<{
        name: string;
        value: string;
        changed: number;
        description: string;
      }>(tagQuery(PROBE_MONITORING_SETTINGS, sourceTag(TAB_INTERNAL, 'settings')));

      for (const row of rows) {
        result.set(String(row.name), {
          value: String(row.value),
          changed: Boolean(row.changed),
          description: String(row.description),
        });
      }
    } catch (error) {
      console.error('[MonitoringCapabilitiesService] probeSettings error:', error);
    }
    return result;
  }

  private async probeZookeeper(): Promise<boolean> {
    try {
      // First check if the system.zookeeper virtual table exists
      const rows = await this.adapter.executeQuery<{ cnt: number }>(tagQuery(PROBE_ZOOKEEPER, sourceTag(TAB_INTERNAL, 'zookeeper')));
      if ((rows[0]?.cnt ?? 0) === 0) return false;

      // Table exists — check if there are any replicated tables as a stronger signal
      try {
        const replicaRows = await this.adapter.executeQuery<{ cnt: number }>(
          tagQuery(`SELECT count() AS cnt FROM (SELECT database, table FROM {{cluster_aware:system.replicas}} GROUP BY database, table) LIMIT 1`, sourceTag(TAB_INTERNAL, 'replicas'))
        );
        return (replicaRows[0]?.cnt ?? 0) > 0;
      } catch {
        // system.replicas might not be accessible, but zookeeper table exists
        return true;
      }
    } catch {
      return false;
    }
  }
  /**
   * Probe introspection functions by actually calling demangle('').
   * This is more reliable than checking system.settings because the
   * setting value can reflect the wrong profile or be stale when
   * set via users.d/ XML config.
   */
  private async probeIntrospectionFunctions(): Promise<boolean> {
    try {
      await this.adapter.executeQuery<{ ok: number }>(
        tagQuery(`SELECT demangle('') AS ok`, sourceTag(TAB_INTERNAL, 'introspection'))
      );
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Check if the CPU profiler is actually producing samples in trace_log.
   * Returns the sample count (0 means profiler is broken or server is idle).
   * Only meaningful when trace_log exists and profiler settings are enabled.
   */
  private async probeCPUProfilerSamples(): Promise<number> {
    try {
      const rows = await this.adapter.executeQuery<{ cnt: number }>(
        tagQuery(PROBE_CPU_PROFILER_SAMPLES, sourceTag(TAB_INTERNAL, 'cpuProfilerProbe'))
      );
      return Number(rows[0]?.cnt ?? 0);
    } catch {
      // trace_log might not exist or be inaccessible
      return 0;
    }
  }

  /**
   * Check if tracehouse sampling tables exist (processes_history, merges_history).
   * Created by infra/scripts/setup_sampling.sh.
   * Uses {{cluster_aware:system.tables}} to find tables across all cluster nodes.
   */
  private async probeTracehouseSamplingTables(): Promise<Map<string, { engine: string; totalRows: number; totalBytes: number }>> {
    const result = new Map<string, { engine: string; totalRows: number; totalBytes: number }>();
    try {
      const rows = await this.adapter.executeQuery<{
        name: string;
        engine: string;
        total_rows: number;
        total_bytes: number;
      }>(tagQuery(PROBE_TRACEHOUSE_SAMPLING_TABLES, sourceTag(TAB_INTERNAL, 'tracehouseProbe')));

      for (const row of rows) {
        result.set(String(row.name), {
          engine: String(row.engine),
          totalRows: Number(row.total_rows) || 0,
          totalBytes: Number(row.total_bytes) || 0,
        });
      }
    } catch {
      // tracehouse database may not exist — that's fine
    }
    return result;
  }

  /**
   * Probe access to operational system tables by attempting a lightweight
   * SELECT. Returns the set of table names that are accessible.
   * Each probe is independent — a permission error on one table doesn't
   * affect the others.
   */
  private async probeSystemTableAccess(): Promise<Set<string>> {
    const accessible = new Set<string>();
    const results = await Promise.allSettled(
      PROBE_SYSTEM_TABLE_ACCESS_TABLES.map(async (table) => {
        await this.adapter.executeQuery(
          tagQuery(
            `SELECT 1 FROM system.${table} LIMIT 0`,
            sourceTag(TAB_INTERNAL, `probe_${table}`)
          )
        );
        return table;
      })
    );
    for (const result of results) {
      if (result.status === 'fulfilled') {
        accessible.add(result.value);
      }
    }
    return accessible;
  }

  private parseVersion(version: string): [number, number] {
    const match = version.match(/^(\d+)\.(\d+)/);
    if (!match) return [0, 0];
    return [parseInt(match[1], 10), parseInt(match[2], 10)];
  }

  /**
   * Detect ClickHouse Cloud by probing for cloud-specific settings
   * or build options. Safe — returns false on any error.
   */
  private async probeCloudService(): Promise<boolean> {
    try {
      const rows = await this.adapter.executeQuery<{ is_cloud: number }>(
        tagQuery(PROBE_CLOUD_SERVICE, sourceTag(TAB_INTERNAL, 'cloudDetect'))
      );
      return rows.length > 0 && Number(rows[0].is_cloud) === 1;
    } catch {
      return false;
    }
  }
}

function formatRowCount(rows: number): string {
  if (rows < 1000) return rows.toString();
  if (rows < 1_000_000) return `${(rows / 1000).toFixed(1)}K`;
  if (rows < 1_000_000_000) return `${(rows / 1_000_000).toFixed(1)}M`;
  return `${(rows / 1_000_000_000).toFixed(1)}B`;
}
