import React, { useState } from 'react';
import type { SimilarQuery, LiteralDiff } from '@tracehouse/core';
import { extractLiterals, diffLiterals, formatLiteral } from '@tracehouse/core';
import { QueryComparisonPanel } from '../../QueryComparisonPanel';
import type { ComparableQuery } from '../../QueryComparisonPanel';
import { formatBytes } from '../../../../stores/databaseStore';
import { formatDurationMs, formatMicroseconds } from '../../../../utils/formatters';
import { QueryKindDot } from '../shared/QueryKindDot';
import { METRIC_COLORS, percentile, type ChartMetric } from '../shared/chartConstants';

export const HistoryTab: React.FC<{
  similarQueries: SimilarQuery[];
  isLoading: boolean;
  error: string | null;
  onRefresh: () => void;
  cpuTimeline?: { t: string; cpu_pct: number }[];
  memTimeline?: { t: string; mem_pct: number }[];
  isLoadingCpu?: boolean;
  limit: number;
  onLimitChange: (limit: number) => void;
  onSelectQuery?: (query: SimilarQuery) => void;
  hashMode: 'normalized' | 'exact';
  onHashModeChange: (mode: 'normalized' | 'exact') => void;
  currentQueryId?: string;
  onViewInTimeTravel?: () => void;
}> = ({ similarQueries, isLoading, error, onRefresh, cpuTimeline, memTimeline, limit, onLimitChange, onSelectQuery, hashMode, onHashModeChange, currentQueryId, onViewInTimeTravel }) => {
  const [selectedMetrics, setSelectedMetrics] = useState<Set<ChartMetric>>(new Set(['duration']));
  const [hoveredPoint, setHoveredPoint] = useState<number | null>(null);
  const [hoveredEvent, setHoveredEvent] = useState<number | null>(null);
  const [eventTooltipPos, setEventTooltipPos] = useState<{ x: number; y: number } | null>(null);
  const [scaleMode, setScaleMode] = useState<'minmax' | 'percentile' | 'p5p95'>('minmax');
  const [showCpuOverlay, setShowCpuOverlay] = useState(false);
  const [showMemOverlay, setShowMemOverlay] = useState(false);
  const [showSettingsEvents, setShowSettingsEvents] = useState(true);
  const [selectedForCompare, setSelectedForCompare] = useState<Set<string>>(new Set());
  const [compareMode, setCompareMode] = useState(false);
  const [settingsPopover, setSettingsPopover] = useState<{ idx: number; x: number; y: number } | null>(null);

  // Sort state
  type SortKey = 'query_id' | 'time' | 'duration' | 'cpu' | 'memory' | 'rows' | 'server' | null;
  const [sortKey, setSortKey] = useState<SortKey>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDir(key === 'time' || key === 'query_id' ? 'asc' : 'desc');
    }
  };

  // Zoom state — time range filter
  const [zoomRange, setZoomRange] = useState<{ start: number; end: number } | null>(null);
  const [brushStart, setBrushStart] = useState<number | null>(null); // SVG x coordinate
  const [brushEnd, setBrushEnd] = useState<number | null>(null);
  const svgRef = React.useRef<SVGSVGElement>(null);

  // Filter queries by zoom range
  const visibleQueries = React.useMemo(() => {
    if (!zoomRange) return similarQueries;
    return similarQueries.filter(q => {
      const t = new Date(q.query_start_time).getTime();
      return t >= zoomRange.start && t <= zoomRange.end;
    });
  }, [similarQueries, zoomRange]);

  // Map from visibleQueries index back to similarQueries index (for hover sync with table)
  const visibleToOriginalIdx = React.useMemo(() => {
    if (!zoomRange) return similarQueries.map((_, i) => i);
    const map: number[] = [];
    similarQueries.forEach((q, i) => {
      const t = new Date(q.query_start_time).getTime();
      if (t >= zoomRange.start && t <= zoomRange.end) map.push(i);
    });
    return map;
  }, [similarQueries, zoomRange]);

  // Sort the display queries
  const sortedQueries = React.useMemo(() => {
    const base = zoomRange ? visibleQueries : similarQueries;
    if (!sortKey) return base;
    const sorted = [...base].sort((a, b) => {
      let cmp = 0;
      switch (sortKey) {
        case 'query_id': cmp = a.query_id.localeCompare(b.query_id); break;
        case 'time': cmp = new Date(a.query_start_time).getTime() - new Date(b.query_start_time).getTime(); break;
        case 'duration': cmp = Number(a.query_duration_ms) - Number(b.query_duration_ms); break;
        case 'cpu': cmp = (Number(a.cpu_time_us) || 0) - (Number(b.cpu_time_us) || 0); break;
        case 'memory': cmp = Number(a.memory_usage) - Number(b.memory_usage); break;
        case 'rows': cmp = (Number(a.result_rows) || 0) - (Number(b.result_rows) || 0); break;
        case 'server': cmp = (a.client_hostname || '').localeCompare(b.client_hostname || ''); break;
      }
      return sortDir === 'asc' ? cmp : -cmp;
    });
    return sorted;
  }, [similarQueries, visibleQueries, zoomRange, sortKey, sortDir]);

  // Map query_id → index in similarQueries (for hover sync with chart)
  const queryIdToOrigIdx = React.useMemo(() => {
    const map = new Map<string, number>();
    similarQueries.forEach((q, i) => map.set(q.query_id, i));
    return map;
  }, [similarQueries]);

  // Compute settings change events — compare each query's Settings to the previous one
  const settingsEvents = React.useMemo(() => {
    const events: { idx: number; changes: { key: string; from: string; to: string }[] }[] = [];
    for (let i = 1; i < similarQueries.length; i++) {
      const prev = similarQueries[i - 1].Settings || {};
      const curr = similarQueries[i].Settings || {};
      const allKeys = new Set([...Object.keys(prev), ...Object.keys(curr)]);
      const changes: { key: string; from: string; to: string }[] = [];
      for (const key of allKeys) {
        const prevVal = prev[key] ?? '(default)';
        const currVal = curr[key] ?? '(default)';
        if (prevVal !== currVal) {
          changes.push({ key, from: prevVal, to: currVal });
        }
      }
      if (changes.length > 0) {
        events.push({ idx: i, changes });
      }
    }
    return events;
  }, [similarQueries]);

  // Build a lookup: query index → settings changes from previous query
  const settingsChangesByIdx = React.useMemo(() => {
    const map = new Map<number, { key: string; from: string; to: string }[]>();
    for (const evt of settingsEvents) {
      map.set(evt.idx, evt.changes);
    }
    return map;
  }, [settingsEvents]);

  // Compute literal diffs — compare each query's SQL literals against the first execution
  // Since all queries share the same normalized_query_hash, the structure is identical
  // but literal values (strings, numbers, dates, IN-lists) may differ
  const literalDiffsByIdx = React.useMemo(() => {
    const map = new Map<number, LiteralDiff[]>();
    if (similarQueries.length < 2) return map;
    const refSql = similarQueries[0].query;
    if (!refSql) return map;
    // refLiterals intentionally unused — extractLiterals called for side-effect validation
    void extractLiterals(refSql);
    for (let i = 1; i < similarQueries.length; i++) {
      const sql = similarQueries[i].query;
      if (!sql) continue;
      const diffs = diffLiterals(refSql, sql);
      if (diffs.length > 0) map.set(i, diffs);
    }
    return map;
  }, [similarQueries]);

  // Check if any queries have literal differences (to decide whether to show the column)
  const hasAnyLiteralDiffs = literalDiffsByIdx.size > 0;

  const toggleMetric = (metric: ChartMetric, e: React.MouseEvent) => {
    const newSet = new Set(selectedMetrics);
    if (e.metaKey || e.ctrlKey) {
      // Multi-select: toggle the clicked metric
      if (newSet.has(metric)) {
        if (newSet.size > 1) newSet.delete(metric); // Keep at least one
      } else {
        newSet.add(metric);
      }
    } else {
      // Single select: replace with just this metric
      newSet.clear();
      newSet.add(metric);
    }
    setSelectedMetrics(newSet);
  };

  if (isLoading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 200 }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: 24, height: 24, borderWidth: 2, borderStyle: 'solid', borderColor: 'var(--border-primary)', borderTopColor: 'var(--text-tertiary)', borderRadius: '50%', animation: 'spin 1s linear infinite', margin: '0 auto 8px' }} />
          <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Loading similar queries...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ padding: 20 }}>
        <div style={{ padding: 16, borderRadius: 8, background: 'rgba(var(--color-error-rgb), 0.1)', border: '1px solid rgba(var(--color-error-rgb), 0.2)' }}>
          <div style={{ fontWeight: 500, color: 'var(--color-error)', marginBottom: 4 }}>Error loading similar queries</div>
          <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{error}</div>
        </div>
      </div>
    );
  }

  if (similarQueries.length === 0) {
    return (
      <div style={{ padding: 40, textAlign: 'center' }}>
        <div style={{ fontSize: 14, color: 'var(--text-tertiary)', marginBottom: 12 }}>No similar queries found</div>
        <button onClick={onRefresh} style={{ padding: '6px 16px', fontSize: 12, borderRadius: 6, border: '1px solid var(--border-primary)', background: 'var(--bg-card)', color: 'var(--text-tertiary)', cursor: 'pointer' }}>Retry</button>
      </div>
    );
  }

  const fmtMs = formatDurationMs;
  const fmtUs = formatMicroseconds;
  const fmtTimeShort = (ts: string) => {
    const d = new Date(ts);
    return `${d.getMonth() + 1}/${d.getDate()} ${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
  };

  // Calculate stats - coerce to numbers in case they come as strings
  // Stats use visibleQueries so they update when zoomed
  const durations = visibleQueries.map(q => Number(q.query_duration_ms));
  const avgDuration = durations.reduce((sum, d) => sum + d, 0) / durations.length;

  // Standard deviation for duration
  const durationVariance = durations.reduce((sum, d) => sum + Math.pow(d - avgDuration, 2), 0) / durations.length;
  const stdDevDuration = Math.sqrt(durationVariance);

  // Stats for other metrics (for deviation indicators — use full dataset for z-scores)
  const cpuTimes = similarQueries.map(q => Number(q.cpu_time_us) || 0);
  const avgCpu = cpuTimes.reduce((sum, c) => sum + c, 0) / cpuTimes.length;
  const stdDevCpu = Math.sqrt(cpuTimes.reduce((sum, c) => sum + Math.pow(c - avgCpu, 2), 0) / cpuTimes.length);

  const memories = similarQueries.map(q => Number(q.memory_usage));
  const avgMemory = memories.reduce((sum, m) => sum + m, 0) / memories.length;
  const stdDevMemory = Math.sqrt(memories.reduce((sum, m) => sum + Math.pow(m - avgMemory, 2), 0) / memories.length);

  // Duration deviation uses full dataset for table z-scores
  const allDurations = similarQueries.map(q => Number(q.query_duration_ms));
  const allAvgDuration = allDurations.reduce((sum, d) => sum + d, 0) / allDurations.length;
  const allStdDevDuration = Math.sqrt(allDurations.reduce((sum, d) => sum + Math.pow(d - allAvgDuration, 2), 0) / allDurations.length);

  const errorCount = visibleQueries.filter(q => q.exception_code !== 0).length;

  // Helper to get deviation color and indicator
  // Returns how many std devs from mean (clamped to -2 to +2 for display)
  const getDeviation = (value: number, avg: number, stdDev: number): { zScore: number; color: string; indicator: string } => {
    if (stdDev === 0) return { zScore: 0, color: 'var(--text-muted)', indicator: '' };
    const zScore = (value - avg) / stdDev;
    const clampedZ = Math.max(-2, Math.min(2, zScore));

    // Color based on how far from mean (for duration/cpu/memory, higher = worse)
    let color = 'var(--text-muted)';
    let indicator = '';
    if (zScore > 1.5) { color = 'var(--color-error)'; indicator = '▲▲'; }
    else if (zScore > 0.75) { color = 'var(--color-warning)'; indicator = '▲'; }
    else if (zScore < -1.5) { color = 'var(--color-success)'; indicator = '▼▼'; }
    else if (zScore < -0.75) { color = '#3fb950'; indicator = '▼'; }

    return { zScore: clampedZ, color, indicator };
  };

  // Get value for chart based on metric
  const getValue = (q: SimilarQuery, metric: ChartMetric): number => {
    switch (metric) {
      case 'duration': return Number(q.query_duration_ms) || 0;
      case 'cpu': return Number(q.cpu_time_us) || 0;
      case 'memory': return Number(q.memory_usage) || 0;
      case 'rows': return Number(q.result_rows) || 0;
      case 'status': return q.exception_code !== 0 ? 1 : 0;
    }
  };

  const formatValue = (v: number, metric: ChartMetric): string => {
    switch (metric) {
      case 'duration': return fmtMs(v);
      case 'cpu': return fmtUs(v);
      case 'memory': return formatBytes(v);
      case 'rows': return v.toLocaleString();
      case 'status': return v === 1 ? 'Error' : 'OK';
    }
  };

  // Get scale range for a metric based on scale mode
  const getScaleRange = (metric: ChartMetric): { min: number; max: number } => {
    const values = visibleQueries.map(q => getValue(q, metric));
    if (values.length === 0) return { min: 0, max: 1 };

    if (scaleMode === 'p5p95' && values.length >= 5 && metric !== 'status') {
      const sorted = [...values].sort((a, b) => a - b);
      const p5 = percentile(sorted, 5);
      const p95 = percentile(sorted, 95);
      if (p5 === p95) {
        return { min: Math.min(...values), max: Math.max(...values, 1) };
      }
      return { min: p5, max: p95 };
    }

    return { min: Math.min(...values), max: Math.max(...values, 1) };
  };

  // Compute percentile reference values for a metric (used in 'percentile' scale mode)
  const getPercentileLines = (metric: ChartMetric): { label: string; p: number; value: number }[] => {
    const values = visibleQueries.map(q => getValue(q, metric));
    if (values.length < 4 || metric === 'status') return [];
    const sorted = [...values].sort((a, b) => a - b);
    return [
      { label: 'p50', p: 50, value: percentile(sorted, 50) },
      { label: 'p95', p: 95, value: percentile(sorted, 95) },
      { label: 'p99', p: 99, value: percentile(sorted, 99) },
    ];
  };

  // Chart dimensions
  const chartHeight = 150;
  const chartPadding = { top: 20, right: 55, bottom: 30, left: 60 };

  const metricButtons: { key: ChartMetric; label: string }[] = [
    { key: 'duration', label: 'Duration' },
    { key: 'cpu', label: 'CPU' },
    { key: 'memory', label: 'Memory' },
    { key: 'rows', label: 'Rows' },
    { key: 'status', label: 'Status' },
  ];

  const selectedMetricsArray = Array.from(selectedMetrics);

  // Current query visibility checks
  const currentQueryInData = currentQueryId != null && similarQueries.some(q => q.query_id === currentQueryId);
  const currentQueryInView = currentQueryId != null && visibleQueries.some(q => q.query_id === currentQueryId);

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', position: 'relative' }}>
      {/* Banner: current query not visible */}
      {currentQueryId != null && !currentQueryInData && similarQueries.length >= limit && (
        <div style={{
          padding: '8px 16px',
          background: 'rgba(245, 158, 11, 0.1)',
          borderBottom: '1px solid rgba(245, 158, 11, 0.2)',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          fontSize: 12,
          color: '#f59e0b',
        }}>
          <span style={{ fontSize: 14 }}>&#9888;</span>
          <span>The query you're viewing is not among the latest {limit} executions. Increase the "Show" limit to find it.</span>
        </div>
      )}
      {currentQueryId != null && currentQueryInData && !currentQueryInView && zoomRange && (
        <div style={{
          padding: '8px 16px',
          background: 'rgba(88, 166, 255, 0.08)',
          borderBottom: '1px solid rgba(88, 166, 255, 0.15)',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          fontSize: 12,
          color: '#58a6ff',
        }}>
          <span style={{ fontSize: 14 }}>&#8505;</span>
          <span>The query you're viewing is outside the zoomed range.</span>
          <button
            onClick={() => setZoomRange(null)}
            style={{
              padding: '2px 8px', fontSize: 11, borderRadius: 4,
              border: '1px solid rgba(88, 166, 255, 0.3)', background: 'transparent',
              color: '#58a6ff', cursor: 'pointer',
            }}
          >Reset zoom</button>
        </div>
      )}
      {/* Stats header */}
      <div style={{ padding: 16, borderBottom: '1px solid var(--border-secondary)', background: 'var(--bg-card)', display: 'flex', gap: 16, flexWrap: 'wrap' }}>
        <div style={{ background: 'var(--bg-code)', padding: '8px 12px', borderRadius: 6 }}>
          <span style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Executions</span>
          <div style={{ fontSize: 13, fontFamily: 'monospace', color: 'var(--text-primary)', marginTop: 4 }}>
            {visibleQueries.length}
            {!zoomRange && visibleQueries.length >= limit && (
              <span
                style={{ fontSize: 9, color: 'var(--text-muted)', fontWeight: 400, marginLeft: 4 }}
              >(latest {limit})</span>
            )}
            {zoomRange && (
              <span style={{ fontSize: 9, color: 'var(--text-muted)', fontWeight: 400, marginLeft: 4 }}>
                of {similarQueries.length}
              </span>
            )}
          </div>
        </div>
        <div style={{ background: 'var(--bg-code)', padding: '8px 12px', borderRadius: 6 }}>
          <span style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Avg Duration</span>
          <div style={{ fontSize: 13, fontFamily: 'monospace', color: '#58a6ff', marginTop: 4 }}>{fmtMs(avgDuration)}</div>
        </div>
        <div style={{ background: 'var(--bg-code)', padding: '8px 12px', borderRadius: 6 }} title="Standard deviation - lower means more consistent">
          <span style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Std Dev</span>
          <div style={{ fontSize: 13, fontFamily: 'monospace', color: 'var(--text-primary)', marginTop: 4 }}>±{fmtMs(stdDevDuration)}</div>
        </div>

        <div style={{ background: 'var(--bg-code)', padding: '8px 12px', borderRadius: 6 }} title="p50 / p95 / p99 percentiles">
          <span style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase' }}>p50 / p95 / p99</span>
          <div style={{ fontSize: 13, fontFamily: 'monospace', color: 'var(--text-primary)', marginTop: 4 }}>
            {fmtMs(percentile([...durations].sort((a, b) => a - b), 50))}
            <span style={{ color: 'var(--text-muted)' }}> / </span>
            <span style={{ color: '#f59e0b' }}>{fmtMs(percentile([...durations].sort((a, b) => a - b), 95))}</span>
            <span style={{ color: 'var(--text-muted)' }}> / </span>
            <span style={{ color: 'var(--color-error)' }}>{fmtMs(percentile([...durations].sort((a, b) => a - b), 99))}</span>
          </div>
        </div>
        <div style={{ background: 'var(--bg-code)', padding: '8px 12px', borderRadius: 6 }}>
          <span style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Errors</span>
          <div style={{ fontSize: 13, fontFamily: 'monospace', color: errorCount > 0 ? 'var(--color-error)' : 'var(--color-success)', marginTop: 4 }}>{errorCount}</div>
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>Match:</span>
            <div className="tabs" style={{ padding: 2 }}>
              {(['normalized', 'exact'] as const).map(m => (
                <button
                  key={m}
                  className={`tab${hashMode === m ? ' active' : ''}`}
                  onClick={() => onHashModeChange(m)}
                  title={m === 'normalized'
                    ? 'Groups queries with same structure but different literal values'
                    : 'Only byte-identical SQL statements'}
                  style={{ border: 'none', padding: '4px 12px', fontSize: 11 }}
                >
                  {m === 'normalized' ? 'Normalized' : 'Exact'}
                </button>
              ))}
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>Show:</span>
            <select
              value={limit}
              onChange={(e) => onLimitChange(Number(e.target.value))}
              style={{
                padding: '4px 8px',
                fontSize: 11,
                fontFamily: 'monospace',
                borderRadius: 4,
                border: '1px solid var(--border-primary)',
                background: 'var(--bg-code)',
                color: 'var(--text-primary)',
                cursor: 'pointer',
              }}
            >
              {[25, 50, 100, 250, 500].map(n => (
                <option key={n} value={n}>{n}</option>
              ))}
            </select>
          </div>
          {onViewInTimeTravel && (
            <div className="tabs" style={{ padding: 2 }}>
              <button
                className="tab"
                onClick={onViewInTimeTravel}
                title="See this query hash across the full system timeline"
                style={{ border: 'none', padding: '4px 12px', fontSize: 11 }}
              >
                Time Travel
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Timeline Chart */}
      <div style={{ padding: 16, borderBottom: '1px solid var(--border-secondary)', position: 'relative' }}>
        {/* Metric selector */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 12, alignItems: 'center', flexWrap: 'wrap' }}>
          {metricButtons.map(({ key, label }) => {
            const isSelected = selectedMetrics.has(key);
            const color = METRIC_COLORS[key];
            return (
              <button
                key={key}
                onClick={(e) => toggleMetric(key, e)}
                style={{
                  padding: '4px 12px',
                  fontSize: 11,
                  borderRadius: 4,
                  border: isSelected ? `1px solid ${color}` : '1px solid var(--border-primary)',
                  background: isSelected ? `${color}20` : 'transparent',
                  color: isSelected ? color : 'var(--text-muted)',
                  cursor: 'pointer',
                  fontWeight: isSelected ? 500 : 400,
                  transition: 'all 0.15s ease',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                }}
              >
                {isSelected && <span style={{ width: 8, height: 8, borderRadius: '50%', background: color }} />}
                {label}
              </button>
            );
          })}
          <span style={{ fontSize: 10, color: 'var(--text-muted)', marginLeft: 8 }}>
            {navigator.platform.includes('Mac') ? '⌘' : 'Ctrl'}+click to compare
          </span>
          {cpuTimeline && cpuTimeline.length >= 2 && (
            <button
              onClick={() => setShowCpuOverlay(!showCpuOverlay)}
              style={{
                fontSize: 10,
                marginLeft: 8,
                display: 'flex',
                alignItems: 'center',
                gap: 4,
                opacity: showCpuOverlay ? 0.9 : 0.4,
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: '2px 4px',
                borderRadius: 4,
                color: '#ef4444',
                transition: 'opacity 0.15s ease',
              }}
              title={showCpuOverlay ? 'Hide server CPU overlay' : 'Show server CPU overlay'}
            >
              <svg width="20" height="6"><line x1="0" y1="3" x2="20" y2="3" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="4,3" strokeOpacity={showCpuOverlay ? 1 : 0.4} /></svg>
              Server CPU
            </button>
          )}
          {memTimeline && memTimeline.length >= 2 && (
            <button
              onClick={() => setShowMemOverlay(!showMemOverlay)}
              style={{
                fontSize: 10,
                marginLeft: 4,
                display: 'flex',
                alignItems: 'center',
                gap: 4,
                opacity: showMemOverlay ? 0.9 : 0.4,
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: '2px 4px',
                borderRadius: 4,
                color: '#8b5cf6',
                transition: 'opacity 0.15s ease',
              }}
              title={showMemOverlay ? 'Hide server memory overlay' : 'Show server memory overlay'}
            >
              <svg width="20" height="6"><line x1="0" y1="3" x2="20" y2="3" stroke="#8b5cf6" strokeWidth="1.5" strokeDasharray="4,3" strokeOpacity={showMemOverlay ? 1 : 0.4} /></svg>
              Server Mem
            </button>
          )}
          {settingsEvents.length > 0 && (
            <button
              onClick={() => setShowSettingsEvents(!showSettingsEvents)}
              style={{
                fontSize: 10,
                marginLeft: 4,
                display: 'flex',
                alignItems: 'center',
                gap: 4,
                opacity: showSettingsEvents ? 0.9 : 0.4,
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: '2px 4px',
                borderRadius: 4,
                color: '#f59e0b',
                transition: 'opacity 0.15s ease',
              }}
              title={showSettingsEvents ? `Hide settings change events (${settingsEvents.length})` : `Show settings change events (${settingsEvents.length})`}
            >
              <svg width="14" height="10"><circle cx="7" cy="5" r="3.5" fill="none" stroke="#f59e0b" strokeWidth="1.5" strokeOpacity={showSettingsEvents ? 1 : 0.4} /><circle cx="7" cy="5" r="1.2" fill="#f59e0b" fillOpacity={showSettingsEvents ? 1 : 0.4} /></svg>
              Settings ({settingsEvents.length})
            </button>
          )}
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
            {(['percentile', 'p5p95'] as const).map(mode => {
              const labels = { percentile: 'p50 p95 p99', p5p95: 'P5–P95' };
              const titles = { percentile: 'Show p50/p95/p99 reference lines', p5p95: 'Zoom to P5–P95 range, reduces outlier impact' };
              const isActive = scaleMode === mode;
              return (
                <button
                  key={mode}
                  onClick={() => setScaleMode(isActive ? 'minmax' : mode)}
                  style={{
                    padding: '3px 8px',
                    fontSize: 10,
                    borderRadius: 4,
                    border: '1px solid var(--border-primary)',
                    background: isActive ? 'rgba(88, 166, 255, 0.15)' : 'transparent',
                    color: isActive ? '#58a6ff' : 'var(--text-muted)',
                    cursor: 'pointer',
                    transition: 'all 0.15s',
                  }}
                  title={titles[mode]}
                >
                  {labels[mode]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Zoom indicator */}
        {zoomRange && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>
              Zoomed: {fmtTimeShort(new Date(zoomRange.start).toISOString())} – {fmtTimeShort(new Date(zoomRange.end).toISOString())}
              <span style={{ marginLeft: 4 }}>({visibleQueries.length} queries)</span>
            </span>
            <button
              onClick={() => setZoomRange(null)}
              style={{
                padding: '2px 8px',
                fontSize: 10,
                borderRadius: 4,
                border: '1px solid var(--border-primary)',
                background: 'transparent',
                color: 'var(--text-muted)',
                cursor: 'pointer',
              }}
            >
              Reset
            </button>
          </div>
        )}

        {/* SVG Chart */}
        <svg
          ref={svgRef}
          width="100%" height={chartHeight + chartPadding.top + chartPadding.bottom}
          style={{ overflow: 'visible', cursor: brushStart !== null ? 'col-resize' : 'crosshair' }}
          viewBox="0 0 800 200"
          preserveAspectRatio="xMidYMid meet"
          onMouseDown={(e) => {
            if (!svgRef.current) return;
            const pt = svgRef.current.createSVGPoint();
            pt.x = e.clientX; pt.y = e.clientY;
            const svgX = Math.max(chartPadding.left, Math.min(800 - chartPadding.right, pt.matrixTransform(svgRef.current.getScreenCTM()!.inverse()).x));
            setBrushStart(svgX);
            setBrushEnd(svgX);
          }}
          onMouseMove={(e) => {
            if (brushStart === null || !svgRef.current) return;
            const pt = svgRef.current.createSVGPoint();
            pt.x = e.clientX; pt.y = e.clientY;
            const svgX = Math.max(chartPadding.left, Math.min(800 - chartPadding.right, pt.matrixTransform(svgRef.current.getScreenCTM()!.inverse()).x));
            setBrushEnd(svgX);
          }}
          onMouseUp={() => {
            if (brushStart !== null && brushEnd !== null && Math.abs(brushEnd - brushStart) > 5) {
              // Convert SVG x coordinates to timestamps
              const chartWidth = 800 - chartPadding.left - chartPadding.right;
              const queryTimes = visibleQueries.map(q => new Date(q.query_start_time).getTime());
              const tMin = queryTimes[0] ?? 0;
              const tMax = queryTimes[queryTimes.length - 1] ?? 0;
              const tRange = tMax - tMin || 1;
              const x1 = Math.min(brushStart, brushEnd);
              const x2 = Math.max(brushStart, brushEnd);
              const t1 = tMin + ((x1 - chartPadding.left) / chartWidth) * tRange;
              const t2 = tMin + ((x2 - chartPadding.left) / chartWidth) * tRange;
              setZoomRange({ start: t1, end: t2 });
            }
            setBrushStart(null);
            setBrushEnd(null);
          }}
          onMouseLeave={() => {
            setBrushStart(null);
            setBrushEnd(null);
          }}
        >
          {/* Brush selection overlay */}
          {brushStart !== null && brushEnd !== null && Math.abs(brushEnd - brushStart) > 2 && (
            <rect
              x={Math.min(brushStart, brushEnd)}
              y={chartPadding.top}
              width={Math.abs(brushEnd - brushStart)}
              height={chartHeight}
              fill="#58a6ff"
              fillOpacity={0.1}
              stroke="#58a6ff"
              strokeWidth={0.5}
              strokeOpacity={0.4}
            />
          )}
          {/* Grid lines - softer */}
          <line x1={chartPadding.left} y1={chartPadding.top} x2={800 - chartPadding.right} y2={chartPadding.top} stroke="var(--border-secondary)" strokeOpacity={0.5} />
          {scaleMode !== 'percentile' && (
            <line x1={chartPadding.left} y1={chartPadding.top + chartHeight / 2} x2={800 - chartPadding.right} y2={chartPadding.top + chartHeight / 2} stroke="var(--border-secondary)" strokeOpacity={0.3} strokeDasharray="4,4" />
          )}
          <line x1={chartPadding.left} y1={chartPadding.top + chartHeight} x2={800 - chartPadding.right} y2={chartPadding.top + chartHeight} stroke="var(--border-secondary)" strokeOpacity={0.5} />

          {/* Percentile reference lines — only in 'percentile' mode with a single metric */}
          {scaleMode === 'percentile' && selectedMetricsArray.length === 1 && (() => {
            const metric = selectedMetricsArray[0];
            const pLines = getPercentileLines(metric);
            if (pLines.length === 0) return null;
            const { min: minVal, max: maxVal } = getScaleRange(metric);
            const pColors: Record<string, string> = { p50: '#3fb950', p95: '#f97316', p99: '#ef4444' };
            return pLines.map(({ label, value }) => {
              if (maxVal === minVal) return null;
              const norm = (value - minVal) / (maxVal - minVal);
              const y = chartPadding.top + chartHeight - (Math.max(0, Math.min(1, norm)) * chartHeight);
              const color = pColors[label] || 'var(--text-muted)';
              return (
                <g key={label}>
                  <line
                    x1={chartPadding.left}
                    y1={y}
                    x2={800 - chartPadding.right}
                    y2={y}
                    stroke={color}
                    strokeWidth={0.75}
                    strokeDasharray="6,4"
                    strokeOpacity={0.5}
                  />
                  <text
                    x={800 - chartPadding.right + 4}
                    y={y}
                    fontSize={8}
                    fill={color}
                    fillOpacity={0.8}
                    dominantBaseline="middle"
                    fontFamily="ui-monospace, monospace"
                  >
                    {label}
                  </text>
                  <text
                    x={chartPadding.left - 8}
                    y={y}
                    fontSize={8}
                    fill={color}
                    fillOpacity={0.8}
                    textAnchor="end"
                    dominantBaseline="middle"
                    fontFamily="ui-monospace, monospace"
                  >
                    {formatValue(value, metric)}
                  </text>
                </g>
              );
            });
          })()}

          {/* Y-axis labels: show "0%" and "100%" for normalized view when multiple metrics */}
          <text x={chartPadding.left - 8} y={chartPadding.top} fontSize={9} fill="var(--text-muted)" textAnchor="end" dominantBaseline="middle">
            {selectedMetricsArray.length > 1 ? '100%' : (scaleMode === 'percentile' ? '' : formatValue(getScaleRange(selectedMetricsArray[0]).max, selectedMetricsArray[0]))}
          </text>
          <text x={chartPadding.left - 8} y={chartPadding.top + chartHeight} fontSize={9} fill="var(--text-muted)" textAnchor="end" dominantBaseline="middle">
            {selectedMetricsArray.length > 1 ? '0%' : (scaleMode === 'percentile' ? '' : formatValue(getScaleRange(selectedMetricsArray[0]).min, selectedMetricsArray[0]))}
          </text>

          {/* Render a line for each selected metric */}
          {selectedMetricsArray.map(metric => {
            const color = METRIC_COLORS[metric];
            const { min: minVal, max: maxVal } = getScaleRange(metric);
            const chartWidth = 800 - chartPadding.left - chartPadding.right;

            // Use time-based X positioning for proper spacing
            const queryTimes = visibleQueries.map(q => new Date(q.query_start_time).getTime());
            const tMin = queryTimes[0];
            const tMax = queryTimes[queryTimes.length - 1];
            const tRange = tMax - tMin || 1;

            const getX = (idx: number) => {
              if (visibleQueries.length === 1) return chartPadding.left + chartWidth / 2;
              return chartPadding.left + ((queryTimes[idx] - tMin) / tRange) * chartWidth;
            };

            // Normalize and clamp value to 0-1 range
            const normalize = (value: number) => {
              if (maxVal === minVal) return 0.5;
              const norm = (value - minVal) / (maxVal - minVal);
              return Math.max(0, Math.min(1, norm));
            };

            // Build all points
            const allPoints = visibleQueries.map((q, i) => ({
              x: getX(i),
              y: chartPadding.top + chartHeight - (normalize(getValue(q, metric)) * chartHeight),
              idx: i,
            }));

            // Simple polyline path — no spline interpolation
            const linePath = allPoints.length >= 2
              ? 'M' + allPoints.map(p => `${p.x},${p.y}`).join(' L')
              : '';

            // Only show dot circles when density allows
            const showDots = visibleQueries.length <= 80;

            return (
              <g key={metric}>
                {/* Line — skip for status since colors vary per point */}
                {metric !== 'status' && allPoints.length >= 2 && (
                  <path
                    d={linePath}
                    fill="none"
                    stroke={color}
                    strokeWidth={1.5}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                )}
                {/* Dots when sparse enough */}
                {showDots && visibleQueries.map((q, i) => {
                  const origIdx = visibleToOriginalIdx[i];
                  const isHovered = hoveredPoint === origIdx;
                  const isCurrent = currentQueryId != null && q.query_id === currentQueryId;
                  const value = getValue(q, metric);
                  const normalized = normalize(value);
                  const isOutlier = normalized <= 0 || normalized >= 1;
                  const pointColor = metric === 'status'
                    ? (q.exception_code !== 0 ? '#f85149' : '#3fb950')
                    : color;
                  return (
                    <g key={`${metric}-point-${i}`}>
                      {isCurrent && (
                        <circle
                          cx={allPoints[i].x}
                          cy={allPoints[i].y}
                          r={8}
                          fill="none"
                          stroke={pointColor}
                          strokeWidth={1.5}
                          strokeOpacity={0.5}
                        />
                      )}
                      <circle
                        cx={allPoints[i].x}
                        cy={allPoints[i].y}
                        r={isHovered ? 5 : isCurrent ? 4.5 : (isOutlier && scaleMode === 'p5p95' ? 4 : 3)}
                        fill={pointColor}
                        stroke={isHovered || isCurrent ? 'var(--bg-primary)' : 'none'}
                        strokeWidth={2}
                        style={{ cursor: 'pointer' }}
                        onMouseEnter={() => setHoveredPoint(origIdx)}
                        onMouseLeave={() => setHoveredPoint(null)}
                      />
                    </g>
                  );
                })}
                {/* Hovered point highlight when dots are hidden */}
                {!showDots && hoveredPoint !== null && (() => {
                  // Find the visible index for the hovered original index
                  const visIdx = visibleToOriginalIdx.indexOf(hoveredPoint);
                  if (visIdx === -1) return null;
                  const value = getValue(visibleQueries[visIdx], metric);
                  const normalized = normalize(value);
                  const pointColor = metric === 'status'
                    ? (visibleQueries[visIdx].exception_code !== 0 ? '#f85149' : '#3fb950')
                    : color;
                  return (
                    <circle
                      cx={getX(visIdx)}
                      cy={chartPadding.top + chartHeight - (normalized * chartHeight)}
                      r={5}
                      fill={pointColor}
                      stroke="var(--bg-primary)"
                      strokeWidth={2}
                    />
                  );
                })()}
                {/* Current query marker — always visible even when dots are hidden */}
                {!showDots && currentQueryId != null && (() => {
                  const visIdx = visibleQueries.findIndex(q => q.query_id === currentQueryId);
                  if (visIdx === -1) return null;
                  const value = getValue(visibleQueries[visIdx], metric);
                  const normalized = normalize(value);
                  const pointColor = metric === 'status'
                    ? (visibleQueries[visIdx].exception_code !== 0 ? '#f85149' : '#3fb950')
                    : color;
                  const cx = getX(visIdx);
                  const cy = chartPadding.top + chartHeight - (Math.max(0, Math.min(1, normalized)) * chartHeight);
                  return (
                    <g>
                      <circle cx={cx} cy={cy} r={8} fill="none" stroke={pointColor} strokeWidth={1.5} strokeOpacity={0.5} />
                      <circle cx={cx} cy={cy} r={4.5} fill={pointColor} stroke="var(--bg-primary)" strokeWidth={2} />
                    </g>
                  );
                })()}
              </g>
            );
          })}

          {/* Invisible hover zones when many points */}
          {visibleQueries.length > 80 && (() => {
            const chartWidth = 800 - chartPadding.left - chartPadding.right;
            const queryTimes = visibleQueries.map(q => new Date(q.query_start_time).getTime());
            const tMin = queryTimes[0];
            const tMax = queryTimes[queryTimes.length - 1];
            const tRange = tMax - tMin || 1;
            return visibleQueries.map((_, i) => {
              const cx = chartPadding.left + ((queryTimes[i] - tMin) / tRange) * chartWidth;
              const origIdx = visibleToOriginalIdx[i];
              return (
                <rect
                  key={`hover-${i}`}
                  x={cx - 3}
                  y={chartPadding.top}
                  width={6}
                  height={chartHeight}
                  fill="transparent"
                  style={{ cursor: 'pointer' }}
                  onMouseEnter={() => setHoveredPoint(origIdx)}
                  onMouseLeave={() => setHoveredPoint(null)}
                />
              );
            });
          })()}

          {/* CPU Load overlay - dotted line */}
          {showCpuOverlay && cpuTimeline && cpuTimeline.length >= 2 && visibleQueries.length >= 2 && (() => {
            const queryTimes = visibleQueries.map(q => new Date(q.query_start_time).getTime());
            const chartWidth = 800 - chartPadding.left - chartPadding.right;
            const qTimeMin = queryTimes[0];
            const qTimeMax = queryTimes[queryTimes.length - 1];
            const qTimeRange = qTimeMax - qTimeMin || 1;

            // CPU data is already aggregated to ~100 buckets server-side
            const cpuPoints = cpuTimeline
              .map(p => {
                const t = new Date(p.t).getTime();
                const x = chartPadding.left + ((t - qTimeMin) / qTimeRange) * chartWidth;
                const y = chartPadding.top + chartHeight - (Math.min(p.cpu_pct, 100) / 100) * chartHeight;
                return { x: Math.max(chartPadding.left, Math.min(800 - chartPadding.right, x)), y, pct: p.cpu_pct };
              });

            if (cpuPoints.length < 2) return null;

            const cpuPath = 'M' + cpuPoints.map(p => `${p.x},${p.y}`).join(' L');

            return (
              <g>
                <path
                  d={cpuPath}
                  fill="none"
                  stroke="#ef4444"
                  strokeWidth={1.5}
                  strokeDasharray="4,3"
                  strokeOpacity={0.5}
                  strokeLinecap="round"
                />
                <text
                  x={800 - chartPadding.right + 4}
                  y={cpuPoints[cpuPoints.length - 1]?.y ?? chartPadding.top}
                  fontSize={8}
                  fill="#ef4444"
                  fillOpacity={0.7}
                  dominantBaseline="middle"
                >
                  CPU {cpuPoints[cpuPoints.length - 1]?.pct.toFixed(0)}%
                </text>
              </g>
            );
          })()}

          {/* Memory Load overlay - dotted line */}
          {showMemOverlay && memTimeline && memTimeline.length >= 2 && visibleQueries.length >= 2 && (() => {
            const queryTimes = visibleQueries.map(q => new Date(q.query_start_time).getTime());
            const chartWidth = 800 - chartPadding.left - chartPadding.right;
            const qTimeMin = queryTimes[0];
            const qTimeMax = queryTimes[queryTimes.length - 1];
            const qTimeRange = qTimeMax - qTimeMin || 1;

            const memPoints = memTimeline
              .map(p => {
                const t = new Date(p.t).getTime();
                const x = chartPadding.left + ((t - qTimeMin) / qTimeRange) * chartWidth;
                const y = chartPadding.top + chartHeight - (Math.min(p.mem_pct, 100) / 100) * chartHeight;
                return { x: Math.max(chartPadding.left, Math.min(800 - chartPadding.right, x)), y, pct: p.mem_pct };
              });

            if (memPoints.length < 2) return null;

            const memPath = 'M' + memPoints.map(p => `${p.x},${p.y}`).join(' L');

            return (
              <g>
                <path
                  d={memPath}
                  fill="none"
                  stroke="#8b5cf6"
                  strokeWidth={1.5}
                  strokeDasharray="4,3"
                  strokeOpacity={0.5}
                  strokeLinecap="round"
                />
                <text
                  x={800 - chartPadding.right + 4}
                  y={memPoints[memPoints.length - 1]?.y ?? chartPadding.top}
                  fontSize={8}
                  fill="#8b5cf6"
                  fillOpacity={0.7}
                  dominantBaseline="middle"
                >
                  Mem {memPoints[memPoints.length - 1]?.pct.toFixed(0)}%
                </text>
              </g>
            );
          })()}

          {/* Settings change event markers */}
          {showSettingsEvents && settingsEvents.length > 0 && (() => {
            const chartWidth = 800 - chartPadding.left - chartPadding.right;
            const queryTimes = visibleQueries.map(q => new Date(q.query_start_time).getTime());
            const tMin = queryTimes[0];
            const tMax = queryTimes[queryTimes.length - 1];
            const tRange = tMax - tMin || 1;
            const getX = (origIdx: number) => {
              const t = new Date(similarQueries[origIdx].query_start_time).getTime();
              if (visibleQueries.length === 1) return chartPadding.left + chartWidth / 2;
              return chartPadding.left + ((t - tMin) / tRange) * chartWidth;
            };
            // Only show events whose original index is within the visible set
            const visibleOrigSet = new Set(visibleToOriginalIdx);
            return settingsEvents.filter(evt => visibleOrigSet.has(evt.idx)).map((evt, evtIdx) => {
              const x = getX(evt.idx);
              const isHovered = hoveredEvent === evtIdx;
              return (
                <g key={`settings-event-${evtIdx}`}>
                  {/* Subtle vertical line */}
                  <line
                    x1={x} y1={chartPadding.top + 2} x2={x} y2={chartPadding.top + chartHeight}
                    stroke="#f59e0b"
                    strokeWidth={0.75}
                    strokeDasharray="2,4"
                    strokeOpacity={isHovered ? 0.6 : 0.25}
                  />
                  {/* Small circle marker at top */}
                  <circle
                    cx={x} cy={chartPadding.top - 4}
                    r={isHovered ? 5 : 4}
                    fill={isHovered ? '#f59e0b' : 'var(--bg-code)'}
                    stroke="#f59e0b"
                    strokeWidth={1.5}
                    strokeOpacity={isHovered ? 1 : 0.6}
                    style={{ cursor: 'pointer', transition: 'all 0.1s ease' }}
                  />
                  {/* Inner dot */}
                  <circle
                    cx={x} cy={chartPadding.top - 4}
                    r={1.5}
                    fill="#f59e0b"
                    fillOpacity={isHovered ? 1 : 0.5}
                    style={{ pointerEvents: 'none' }}
                  />
                  {/* Invisible hover zone — tracks mouse position for HTML tooltip */}
                  <rect
                    x={x - 10} y={chartPadding.top - 12} width={20} height={chartHeight + 14}
                    fill="transparent"
                    style={{ cursor: 'pointer' }}
                    onMouseEnter={(e) => {
                      setHoveredEvent(evtIdx);
                      const svgEl = (e.target as SVGElement).closest('svg');
                      if (svgEl) {
                        const parentRect = svgEl.parentElement?.getBoundingClientRect();
                        if (parentRect) {
                          setEventTooltipPos({
                            x: e.clientX - parentRect.left,
                            y: e.clientY - parentRect.top,
                          });
                        }
                      }
                    }}
                    onMouseMove={(e) => {
                      const svgEl = (e.target as SVGElement).closest('svg');
                      if (svgEl) {
                        const parentRect = svgEl.parentElement?.getBoundingClientRect();
                        if (parentRect) {
                          setEventTooltipPos({
                            x: e.clientX - parentRect.left,
                            y: e.clientY - parentRect.top,
                          });
                        }
                      }
                    }}
                    onMouseLeave={() => {
                      setHoveredEvent(null);
                      setEventTooltipPos(null);
                    }}
                  />
                </g>
              );
            });
          })()}

          {/* Tooltip for hovered point */}
          {hoveredPoint !== null && (
            <g style={{ pointerEvents: 'none' }}>
              {(() => {
                const q = similarQueries[hoveredPoint];
                if (!q) return null;
                const chartWidth = 800 - chartPadding.left - chartPadding.right;
                // Time-based X positioning matching the chart (use visible range)
                const queryTimes = visibleQueries.map(sq => new Date(sq.query_start_time).getTime());
                const tMin = queryTimes[0];
                const tMax = queryTimes[queryTimes.length - 1];
                const tRange = tMax - tMin || 1;
                const qTime = new Date(q.query_start_time).getTime();
                const xNum = visibleQueries.length === 1
                  ? chartPadding.left + chartWidth / 2
                  : chartPadding.left + ((qTime - tMin) / tRange) * chartWidth;
                // Find nearest CPU value for this query's timestamp
                let cpuAtPoint: number | null = null;
                if (showCpuOverlay && cpuTimeline && cpuTimeline.length > 0) {
                  const qTime = new Date(q.query_start_time).getTime();
                  let bestDist = Infinity;
                  for (const cp of cpuTimeline) {
                    const d = Math.abs(new Date(cp.t).getTime() - qTime);
                    if (d < bestDist) { bestDist = d; cpuAtPoint = cp.cpu_pct; }
                  }
                }
                // Find nearest memory value for this query's timestamp
                let memAtPoint: number | null = null;
                if (showMemOverlay && memTimeline && memTimeline.length > 0) {
                  const qTime = new Date(q.query_start_time).getTime();
                  let bestDist = Infinity;
                  for (const mp of memTimeline) {
                    const d = Math.abs(new Date(mp.t).getTime() - qTime);
                    if (d < bestDist) { bestDist = d; memAtPoint = mp.mem_pct; }
                  }
                }
                const hasCpu = cpuAtPoint !== null;
                const hasMem = memAtPoint !== null;
                const tooltipHeight = 20 + selectedMetricsArray.length * 14 + (hasCpu ? 14 : 0) + (hasMem ? 14 : 0);
                // Clamp tooltip position to stay within chart bounds
                const tooltipX = Math.max(70, Math.min(xNum, 800 - 70));
                return (
                  <>
                    <rect
                      x={tooltipX - 70}
                      y={chartPadding.top - 5}
                      width={140}
                      height={tooltipHeight}
                      rx={4}
                      fill="var(--bg-primary)"
                      stroke="var(--border-primary)"
                    />
                    <text x={tooltipX} y={chartPadding.top + 8} fontSize={9} fill="var(--text-muted)" textAnchor="middle">
                      {fmtTimeShort(q.query_start_time)}
                    </text>
                    {selectedMetricsArray.map((metric, idx) => (
                      <text
                        key={metric}
                        x={tooltipX}
                        y={chartPadding.top + 22 + idx * 14}
                        fontSize={10}
                        fill={METRIC_COLORS[metric]}
                        textAnchor="middle"
                      >
                        {metric}: {formatValue(getValue(q, metric), metric)}
                      </text>
                    ))}
                    {hasCpu && (
                      <text
                        x={tooltipX}
                        y={chartPadding.top + 22 + selectedMetricsArray.length * 14}
                        fontSize={10}
                        fill="#ef4444"
                        textAnchor="middle"
                      >
                        server cpu: {cpuAtPoint!.toFixed(1)}%
                      </text>
                    )}
                    {hasMem && (
                      <text
                        x={tooltipX}
                        y={chartPadding.top + 22 + selectedMetricsArray.length * 14 + (hasCpu ? 14 : 0)}
                        fontSize={10}
                        fill="#8b5cf6"
                        textAnchor="middle"
                      >
                        server mem: {memAtPoint!.toFixed(1)}%
                      </text>
                    )}
                  </>
                );
              })()}
            </g>
          )}

          {/* X-axis time labels */}
          {visibleQueries.length > 0 && (
            <>
              <text x={chartPadding.left} y={chartPadding.top + chartHeight + 16} fontSize={9} fill="var(--text-muted)" textAnchor="start">
                {fmtTimeShort(visibleQueries[0].query_start_time)}
              </text>
              <text x={800 - chartPadding.right} y={chartPadding.top + chartHeight + 16} fontSize={9} fill="var(--text-muted)" textAnchor="end">
                {fmtTimeShort(visibleQueries[visibleQueries.length - 1].query_start_time)}
              </text>
            </>
          )}
        </svg>

        {/* HTML tooltip for settings events — positioned near mouse */}
        {hoveredEvent !== null && eventTooltipPos && settingsEvents[hoveredEvent] && (
          <div
            style={{
              position: 'absolute',
              left: eventTooltipPos.x,
              top: eventTooltipPos.y,
              transform: 'translate(-50%, -100%) translateY(-12px)',
              zIndex: 30,
              background: 'var(--bg-primary)',
              border: '1px solid rgba(245, 158, 11, 0.3)',
              borderRadius: 6,
              padding: '6px 10px',
              pointerEvents: 'none',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.25)',
              minWidth: 160,
              maxWidth: 260,
            }}
          >
            <div style={{ fontSize: 9, fontWeight: 600, color: '#f59e0b', marginBottom: 4, letterSpacing: '0.3px' }}>
              Settings changed
            </div>
            {settingsEvents[hoveredEvent].changes.map((c, ci) => (
              <div key={ci} style={{ fontSize: 10, fontFamily: 'monospace', color: 'var(--text-tertiary)', lineHeight: '16px', whiteSpace: 'nowrap' }}>
                <span style={{ color: 'var(--text-muted)' }}>{c.key}:</span>{' '}
                <span style={{ color: 'var(--color-error)', textDecoration: 'line-through', opacity: 0.6 }}>{c.from}</span>{' '}
                <span style={{ color: 'var(--text-muted)' }}>→</span>{' '}
                <span style={{ color: 'var(--color-success)' }}>{c.to}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Compare mode bar — fixed above scroll area */}
      <div style={{
        padding: '8px 16px',
        borderBottom: '1px solid var(--border-secondary)',
        background: 'var(--bg-card)',
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        flexShrink: 0,
      }}>
        <button
          onClick={() => {
            if (compareMode) {
              setCompareMode(false);
              setSelectedForCompare(new Set());
            } else {
              setCompareMode(true);
            }
          }}
          style={{
            padding: '5px 14px',
            fontSize: 11,
            borderRadius: 5,
            border: compareMode ? '1px solid #58a6ff' : '1px solid var(--border-primary)',
            background: compareMode ? 'rgba(88, 166, 255, 0.15)' : 'transparent',
            color: compareMode ? '#58a6ff' : 'var(--text-muted)',
            cursor: 'pointer',
            fontWeight: compareMode ? 600 : 400,
            transition: 'all 0.15s',
          }}
        >
          {compareMode ? 'Cancel Compare' : '⇄ Compare Queries'}
        </button>
        {compareMode && (
          <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
            {selectedForCompare.size === 0
              ? 'Select 2 or more queries to compare'
              : `${selectedForCompare.size} selected`}
          </span>
        )}
      </div>
      {/* Fixed header row */}
      <table style={{ width: '100%', borderCollapse: 'collapse', flexShrink: 0, tableLayout: 'fixed' }}>
        <colgroup>
          <col style={{ width: '3%' }} />   {/* Type dot */}
          <col style={{ width: '7%' }} />   {/* Query ID */}
          <col style={{ width: '8%' }} />   {/* Time */}
          <col style={{ width: '9%' }} />   {/* Duration */}
          <col style={{ width: '9%' }} />   {/* CPU */}
          <col style={{ width: '9%' }} />   {/* Memory */}
          <col style={{ width: '6%' }} />   {/* Rows */}
          <col style={{ width: '10%' }} />  {/* Server */}
          <col style={{ width: '3%' }} />   {/* Status icon */}
          <col style={{ width: '9%' }} />   {/* Settings */}
          <col style={{ width: '13%' }} />  {/* Changes */}
          {hasAnyLiteralDiffs ? <col style={{ width: '14%' }} /> : null}  {/* Params */}
        </colgroup>
        <thead>
          <tr>
            {([
              { label: '', key: null },
              { label: 'Query ID', key: 'query_id' as SortKey },
              { label: 'Time', key: 'time' as SortKey },
              { label: 'Duration', key: 'duration' as SortKey },
              { label: 'CPU', key: 'cpu' as SortKey },
              { label: 'Memory', key: 'memory' as SortKey },
              { label: 'Rows', key: 'rows' as SortKey },
              { label: 'Server', key: 'server' as SortKey },
              { label: '', key: null },
              { label: 'Settings', key: null },
              { label: 'Changes', key: null },
            ]).map((col, ci) => (
              <th
                key={ci}
                onClick={col.key ? () => handleSort(col.key) : undefined}
                style={{
                  background: 'var(--bg-card)',
                  padding: '8px 8px',
                  fontSize: 10,
                  fontWeight: 600,
                  color: sortKey === col.key ? 'var(--text-primary)' : 'var(--text-muted)',
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px',
                  borderBottom: '1px solid var(--border-secondary)',
                  textAlign: 'left',
                  whiteSpace: 'nowrap',
                  cursor: col.key ? 'pointer' : 'default',
                  userSelect: 'none',
                  transition: 'color 0.15s ease',
                }}
              >
                {col.label}
                {sortKey === col.key && (
                  <span style={{ marginLeft: 3, fontSize: 9 }}>{sortDir === 'asc' ? '▲' : '▼'}</span>
                )}
              </th>
            ))}
            {hasAnyLiteralDiffs && (
              <th style={{ background: 'var(--bg-card)', padding: '8px 8px', fontSize: 10, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', borderBottom: '1px solid var(--border-secondary)', textAlign: 'left', whiteSpace: 'nowrap' }}>
                Params
              </th>
            )}
          </tr>
        </thead>
      </table>
      {/* Scrollable rows */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
          <colgroup>
            <col style={{ width: '3%' }} />
            <col style={{ width: '7%' }} />
            <col style={{ width: '8%' }} />
            <col style={{ width: '9%' }} />
            <col style={{ width: '9%' }} />
            <col style={{ width: '9%' }} />
            <col style={{ width: '6%' }} />
            <col style={{ width: '10%' }} />
            <col style={{ width: '3%' }} />
            <col style={{ width: '9%' }} />
            <col style={{ width: '13%' }} />
            {hasAnyLiteralDiffs ? <col style={{ width: '14%' }} /> : null}
          </colgroup>
          <tbody>
            {sortedQueries.map((q, i) => {
              const origIdx = queryIdToOrigIdx.get(q.query_id) ?? i;
              const durationVal = Number(q.query_duration_ms);
              const cpuVal = Number(q.cpu_time_us) || 0;
              const memVal = Number(q.memory_usage);

              const durationDev = getDeviation(durationVal, allAvgDuration, allStdDevDuration);
              const cpuDev = getDeviation(cpuVal, avgCpu, stdDevCpu);
              const memDev = getDeviation(memVal, avgMemory, stdDevMemory);

              // Collect non-default settings for this query
              const settings = q.Settings || {};
              const settingKeys = Object.keys(settings);
              const settingsCount = settingKeys.length;

              const isCurrentQuery = currentQueryId != null && q.query_id === currentQueryId;
              return (
                <tr
                  key={q.query_id}
                  style={{
                    fontSize: 11,
                    background: hoveredPoint === origIdx ? 'var(--bg-hover)' : (selectedForCompare.has(q.query_id) ? 'rgba(88, 166, 255, 0.08)' : isCurrentQuery ? 'rgba(245, 158, 11, 0.06)' : (i % 2 === 0 ? 'transparent' : 'var(--bg-card)')),
                    transition: 'background 0.1s ease',
                    cursor: compareMode ? 'pointer' : 'default',
                    borderLeft: isCurrentQuery ? '2px solid #f59e0b' : '2px solid transparent',
                  }}
                  onMouseEnter={() => setHoveredPoint(origIdx)}
                  onMouseLeave={() => setHoveredPoint(null)}
                  onClick={() => {
                    if (compareMode) {
                      setSelectedForCompare(prev => {
                        const next = new Set(prev);
                        if (next.has(q.query_id)) next.delete(q.query_id); else next.add(q.query_id);
                        return next;
                      });
                    }
                  }}
                >
                  {/* Type dot */}
                  <td style={{ padding: '8px 4px 8px 8px', borderBottom: '1px solid var(--border-secondary)', textAlign: 'center' }}>
                    <QueryKindDot kind={q.query_kind || ''} />
                  </td>
                  <td style={{ padding: '8px 8px', borderBottom: '1px solid var(--border-secondary)' }}>
                    <span style={{ fontFamily: 'monospace', fontSize: 10, color: onSelectQuery && !compareMode ? '#58a6ff' : 'var(--text-tertiary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'flex', alignItems: 'center', gap: 4, cursor: onSelectQuery && !compareMode ? 'pointer' : 'default', textDecoration: onSelectQuery && !compareMode ? 'underline' : 'none', textDecorationColor: 'rgba(88,166,255,0.3)', textUnderlineOffset: '2px' }} title={`${q.query_id}${onSelectQuery && !compareMode ? '\nClick to view details' : ''}`}
                      onClick={(e) => {
                        if (compareMode) return; // let row handler deal with it
                        if (onSelectQuery) {
                          e.stopPropagation();
                          onSelectQuery(q);
                        }
                      }}
                    >
                      {compareMode && (
                        <span style={{ width: 14, height: 14, borderRadius: 3, border: selectedForCompare.has(q.query_id) ? '2px solid #58a6ff' : '1px solid var(--border-primary)', background: selectedForCompare.has(q.query_id) ? '#58a6ff' : 'transparent', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 9, color: '#fff' }}>
                          {selectedForCompare.has(q.query_id) ? '✓' : ''}
                        </span>
                      )}
                      {q.query_id.substring(0, 8)}
                      {isCurrentQuery && (
                        <span style={{
                          fontSize: 8, padding: '1px 4px', borderRadius: 3,
                          background: 'rgba(245, 158, 11, 0.15)', color: '#f59e0b',
                          fontFamily: 'system-ui, sans-serif', fontWeight: 500, flexShrink: 0,
                        }}>current</span>
                      )}
                    </span>
                  </td>
                  <td style={{ padding: '8px 8px', borderBottom: '1px solid var(--border-secondary)', whiteSpace: 'nowrap' }}>
                    <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{fmtTimeShort(q.query_start_time)}</span>
                  </td>
                  <td style={{ padding: '8px 8px', borderBottom: '1px solid var(--border-secondary)', whiteSpace: 'nowrap' }}>
                    <span style={{ fontFamily: 'monospace', display: 'flex', alignItems: 'center', gap: 4 }} title={`${durationDev.zScore > 0 ? '+' : ''}${(durationDev.zScore).toFixed(1)}σ from avg`}>
                      <span style={{ color: '#58a6ff' }}>{fmtMs(durationVal)}</span>
                      {durationDev.indicator && <span style={{ fontSize: 8, color: durationDev.color }}>{durationDev.indicator}</span>}
                    </span>
                  </td>
                  <td style={{ padding: '8px 8px', borderBottom: '1px solid var(--border-secondary)', whiteSpace: 'nowrap' }}>
                    <span style={{ fontFamily: 'monospace', display: 'flex', alignItems: 'center', gap: 4 }} title={`${cpuDev.zScore > 0 ? '+' : ''}${(cpuDev.zScore).toFixed(1)}σ from avg`}>
                      <span style={{ color: 'var(--text-tertiary)' }}>{fmtUs(cpuVal)}</span>
                      {cpuDev.indicator && <span style={{ fontSize: 8, color: cpuDev.color }}>{cpuDev.indicator}</span>}
                    </span>
                  </td>
                  <td style={{ padding: '8px 8px', borderBottom: '1px solid var(--border-secondary)', whiteSpace: 'nowrap' }}>
                    <span style={{ fontFamily: 'monospace', display: 'flex', alignItems: 'center', gap: 4 }} title={`${memDev.zScore > 0 ? '+' : ''}${(memDev.zScore).toFixed(1)}σ from avg`}>
                      <span style={{ color: 'var(--text-tertiary)' }}>{formatBytes(memVal)}</span>
                      {memDev.indicator && <span style={{ fontSize: 8, color: memDev.color }}>{memDev.indicator}</span>}
                    </span>
                  </td>
                  <td style={{ padding: '8px 8px', borderBottom: '1px solid var(--border-secondary)', whiteSpace: 'nowrap' }}>
                    <span style={{ fontFamily: 'monospace', color: 'var(--text-tertiary)' }}>{(Number(q.result_rows) || 0).toLocaleString()}</span>
                  </td>
                  <td style={{ padding: '8px 8px', borderBottom: '1px solid var(--border-secondary)', whiteSpace: 'nowrap' }}>
                    <span style={{ fontFamily: 'monospace', fontSize: 10, color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block' }} title={q.client_hostname || '—'}>{q.client_hostname || '—'}</span>
                  </td>
                  <td style={{ padding: '8px 8px', borderBottom: '1px solid var(--border-secondary)' }}>
                    <span style={{ fontSize: 10, color: q.exception_code !== 0 ? 'var(--color-error)' : 'var(--color-success)' }}>{q.exception_code !== 0 ? '✗' : '✓'}</span>
                  </td>
                  <td style={{ padding: '8px 8px', borderBottom: '1px solid var(--border-secondary)', overflow: 'visible' }}>
                    {settingsCount > 0 ? (
                      <span
                        style={{
                          fontSize: 10,
                          color: '#f59e0b',
                          cursor: 'pointer',
                          padding: '2px 6px',
                          borderRadius: 4,
                          background: 'rgba(245, 158, 11, 0.1)',
                          border: '1px solid rgba(245, 158, 11, 0.2)',
                          display: 'inline-block',
                        }}
                        onMouseEnter={(e) => {
                          const rect = e.currentTarget.getBoundingClientRect();
                          setSettingsPopover({ idx: i, x: rect.right, y: rect.top });
                        }}
                        onMouseLeave={(e) => {
                          // Only close if mouse isn't moving to the popover
                          const related = e.relatedTarget as HTMLElement | null;
                          if (related?.closest?.('.settings-popover-panel')) return;
                          setSettingsPopover(null);
                        }}
                      >
                        {settingsCount} setting{settingsCount > 1 ? 's' : ''}
                      </span>
                    ) : (
                      <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>—</span>
                    )}
                  </td>
                  {/* Changes column — settings diff from previous query */}
                  <td style={{ padding: '8px 8px', borderBottom: '1px solid var(--border-secondary)', overflow: 'visible' }}>
                    {(() => {
                      const changes = settingsChangesByIdx.get(i);
                      if (!changes || changes.length === 0) {
                        return i === 0
                          ? <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>—</span>
                          : <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>—</span>;
                      }
                      return (
                        <span
                          style={{
                            fontSize: 10,
                            color: '#f59e0b',
                            padding: '2px 6px',
                            borderRadius: 4,
                            background: 'rgba(245, 158, 11, 0.08)',
                            border: '1px solid rgba(245, 158, 11, 0.15)',
                            display: 'inline-block',
                            cursor: 'default',
                          }}
                          title={changes.map(c => `${c.key}: ${c.from} → ${c.to}`).join('\n')}
                        >
                          {changes.map((c, ci) => (
                            <span key={ci} style={{ display: 'block', whiteSpace: 'nowrap', lineHeight: '15px' }}>
                              <span style={{ color: 'var(--text-muted)' }}>{c.key}:</span>{' '}
                              <span style={{ color: 'var(--color-error)', textDecoration: 'line-through', opacity: 0.6, fontSize: 9 }}>{c.from}</span>{' '}
                              <span style={{ color: 'var(--text-muted)', fontSize: 8 }}>→</span>{' '}
                              <span style={{ color: 'var(--color-success)', fontSize: 9 }}>{c.to}</span>
                            </span>
                          ))}
                        </span>
                      );
                    })()}
                  </td>
                  {/* Params column — literal value diffs vs first execution */}
                  {hasAnyLiteralDiffs && (
                    <td style={{ padding: '8px 8px', borderBottom: '1px solid var(--border-secondary)', overflow: 'visible', maxWidth: 220 }}>
                      {(() => {
                        if (i === 0) {
                          return <span style={{ fontSize: 10, color: 'var(--text-muted)', fontStyle: 'italic' }}>ref</span>;
                        }
                        const diffs = literalDiffsByIdx.get(i);
                        if (!diffs || diffs.length === 0) {
                          return <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>same</span>;
                        }
                        // Show up to 3 diffs inline, rest as count
                        const shown = diffs.slice(0, 3);
                        const remaining = diffs.length - shown.length;
                        return (
                          <span
                            style={{
                              fontSize: 10,
                              padding: '2px 6px',
                              borderRadius: 4,
                              background: 'rgba(88, 166, 255, 0.06)',
                              border: '1px solid rgba(88, 166, 255, 0.15)',
                              display: 'inline-block',
                              cursor: 'default',
                            }}
                            title={diffs.map(d => `${d.context ? d.context + ': ' : '#' + d.index + ': '}${formatLiteral(d.reference, 40)} → ${formatLiteral(d.current, 40)}`).join('\n')}
                          >
                            {shown.map((d, di) => (
                              <span key={di} style={{ display: 'block', whiteSpace: 'nowrap', lineHeight: '15px', fontFamily: 'monospace' }}>
                                {d.context && <span style={{ color: 'var(--text-muted)', fontSize: 9 }}>{d.context}: </span>}
                                <span style={{ color: 'var(--text-muted)', opacity: 0.6, textDecoration: 'line-through', fontSize: 9 }}>{formatLiteral(d.reference, 12)}</span>
                                <span style={{ color: 'var(--text-muted)', fontSize: 8 }}> → </span>
                                <span style={{ color: '#58a6ff', fontSize: 9 }}>{formatLiteral(d.current, 12)}</span>
                              </span>
                            ))}
                            {remaining > 0 && (
                              <span style={{ display: 'block', fontSize: 9, color: 'var(--text-muted)', lineHeight: '15px' }}>
                                +{remaining} more
                              </span>
                            )}
                          </span>
                        );
                      })()}
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Comparison panel */}
      {compareMode && selectedForCompare.size >= 2 && (() => {
        const selected = similarQueries.filter(q => selectedForCompare.has(q.query_id));
        const comparableQueries: ComparableQuery[] = selected.map(q => ({
          query_id: q.query_id,
          query_start_time: q.query_start_time,
          query_duration_ms: q.query_duration_ms,
          read_rows: q.read_rows,
          read_bytes: q.read_bytes,
          result_rows: q.result_rows,
          memory_usage: q.memory_usage,
          cpu_time_us: q.cpu_time_us,
          exception_code: q.exception_code,
          exception: q.exception,
          Settings: q.Settings,
          hostname: q.client_hostname,
        }));
        return (
          <QueryComparisonPanel
            queries={comparableQueries}
            mode="overlay"
            onClose={() => {
              setCompareMode(false);
              setSelectedForCompare(new Set());
            }}
          />
        );
      })()}

      {/* Settings popover - positioned via state to avoid clipping */}
      {settingsPopover !== null && (() => {
        const q = similarQueries[settingsPopover.idx];
        const s = q?.Settings;
        if (!s || typeof s !== 'object') return null;
        const keys = Object.keys(s);
        if (keys.length === 0) return null;
        return (
          <div
            className="settings-popover-panel"
            onMouseLeave={() => setSettingsPopover(null)}
            style={{
              position: 'fixed',
              right: document.documentElement.clientWidth - settingsPopover.x + 4,
              top: settingsPopover.y,
              transform: 'translateY(-50%)',
              zIndex: 9999,
              background: 'var(--bg-primary)',
              border: '1px solid var(--border-accent)',
              borderRadius: 8,
              padding: '8px 0',
              minWidth: 280,
              maxWidth: 400,
              boxShadow: '0 8px 24px rgba(0,0,0,0.3)',
            }}
          >
            <div style={{ padding: '4px 12px 8px', fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', borderBottom: '1px solid var(--border-secondary)' }}>Query Settings</div>
            {keys.map(k => (
              <div key={k} style={{ padding: '6px 12px', display: 'flex', justifyContent: 'space-between', gap: 12, fontSize: 11 }}>
                <span style={{ color: 'var(--text-tertiary)', fontFamily: 'monospace' }}>{k}</span>
                <span style={{ color: '#f59e0b', fontFamily: 'monospace', fontWeight: 500 }}>{s[k]}</span>
              </div>
            ))}
          </div>
        );
      })()}
    </div>
  );
};
